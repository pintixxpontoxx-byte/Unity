# Configuração da cena no Unity

1. Crie um Canvas em `Screen Space - Overlay`.
2. Adicione um EventSystem (GameObject > UI > Event System).
3. No Canvas, adicione `GraphicRaycaster`.
4. Crie um pequeno Image circular chamado `HandCursor` e deixe-o inicialmente ativo.
5. Crie um GameObject `HandFrameReceiver` e adicione o script `HandFrameReceiver`.
6. Crie um GameObject `HandCursorController`, adicione `HandCursorController` e arraste para os campos: `HandCursor`, Canvas e GraphicRaycaster.
7. Para cada botão de aplicativo, adicione `HandOSMenuButton`, preencha o Package ID e ligue `OpenApp()` ao evento OnClick do Button.
8. Importe MediaPipe Hand Landmarker para Unity e crie um adaptador que leia os landmarks 4 e 8 e publique `HandLandmarkFrame` em `HandFrameReceiver.Instance.Publish(frame)`.

## Nota importante sobre o gesto
Os valores de pinça são pontos normalizados na imagem. A escala pode variar conforme o enquadramento; ajuste `pinchStart` e `pinchEnd` depois de testar no aparelho.
