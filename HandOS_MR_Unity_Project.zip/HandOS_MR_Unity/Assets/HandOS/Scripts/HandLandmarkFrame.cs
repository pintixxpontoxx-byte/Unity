using UnityEngine;

namespace HandOS
{
    [System.Serializable]
    public struct HandLandmarkFrame
    {
        // Normalized coordinates, origin at top-left.
        public Vector2 indexTip;   // MediaPipe landmark 8
        public Vector2 thumbTip;   // MediaPipe landmark 4
        public Vector2 indexBase;  // MediaPipe landmark 5
        public Vector2 pinkyBase;  // MediaPipe landmark 17
        public bool hasHand;
        public float timestamp;
    }
}
