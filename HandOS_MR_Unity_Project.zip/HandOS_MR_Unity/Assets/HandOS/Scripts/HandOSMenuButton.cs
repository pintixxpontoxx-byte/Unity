using UnityEngine;

namespace HandOS
{
    public sealed class HandOSMenuButton : MonoBehaviour
    {
        [SerializeField] private string androidPackageId;

        public void OpenApp()
        {
            if (!AndroidAppLauncher.Launch(androidPackageId))
                Debug.LogWarning("Não foi possível abrir o pacote: " + androidPackageId);
        }
    }
}
