using System;
using UnityEngine;

namespace HandOS
{
    // Connect a MediaPipe Hand Landmarker adapter to Publish().
    public sealed class HandFrameReceiver : MonoBehaviour
    {
        public static HandFrameReceiver Instance { get; private set; }
        public event Action<HandLandmarkFrame> FrameReceived;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
        }

        public void Publish(HandLandmarkFrame frame)
        {
            FrameReceived?.Invoke(frame);
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }
    }
}
