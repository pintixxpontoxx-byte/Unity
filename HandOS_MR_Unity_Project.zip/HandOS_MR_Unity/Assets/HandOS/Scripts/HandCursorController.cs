using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace HandOS
{
    public sealed class HandCursorController : MonoBehaviour
    {
        [Header("References")]
        [SerializeField] private RectTransform cursor;
        [SerializeField] private Canvas canvas;
        [SerializeField] private GraphicRaycaster raycaster;

        [Header("Gesture")]
        [SerializeField, Range(0.01f, 0.20f)] private float pinchStart = 0.055f;
        [SerializeField, Range(0.02f, 0.30f)] private float pinchEnd = 0.085f;
        [SerializeField, Range(0.01f, 1f)] private float smoothing = 0.35f;

        private bool pinching;
        private Vector2 smoothed;
        private bool hasSmoothed;
        private PointerEventData pointer;
        private GameObject pressedObject;
        private readonly List<RaycastResult> hits = new List<RaycastResult>();

        private void OnEnable()
        {
            if (HandFrameReceiver.Instance != null)
                HandFrameReceiver.Instance.FrameReceived += OnFrame;
        }

        private void Start()
        {
            // Handles the common case where this component starts after the receiver.
            if (HandFrameReceiver.Instance != null)
                HandFrameReceiver.Instance.FrameReceived += OnFrame;
        }

        private void OnDisable()
        {
            if (HandFrameReceiver.Instance != null)
                HandFrameReceiver.Instance.FrameReceived -= OnFrame;
            EndPinch();
        }

        private void OnFrame(HandLandmarkFrame frame)
        {
            if (cursor == null || canvas == null) return;

            if (!frame.hasHand)
            {
                cursor.gameObject.SetActive(false);
                EndPinch();
                hasSmoothed = false;
                return;
            }

            cursor.gameObject.SetActive(true);
            smoothed = hasSmoothed ? Vector2.Lerp(smoothed, frame.indexTip, smoothing) : frame.indexTip;
            hasSmoothed = true;

            Vector2 screen = new Vector2(
                Mathf.Clamp01(smoothed.x) * Screen.width,
                (1f - Mathf.Clamp01(smoothed.y)) * Screen.height);

            RectTransform canvasRect = canvas.transform as RectTransform;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(
                canvasRect, screen,
                canvas.renderMode == RenderMode.ScreenSpaceOverlay ? null : canvas.worldCamera,
                out Vector2 local);
            cursor.anchoredPosition = local;

            float distance = Vector2.Distance(frame.indexTip, frame.thumbTip);
            if (!pinching && distance <= pinchStart) BeginPinch(screen);
            else if (pinching && distance >= pinchEnd) EndPinch();

            if (pinching) UpdateDrag(screen);
        }

        private void BeginPinch(Vector2 screen)
        {
            pinching = true;
            if (EventSystem.current == null || raycaster == null) return;

            pointer = new PointerEventData(EventSystem.current) { position = screen };
            hits.Clear();
            raycaster.Raycast(pointer, hits);
            if (hits.Count == 0) return;

            pressedObject = hits[0].gameObject;
            ExecuteEvents.Execute(pressedObject, pointer, ExecuteEvents.pointerEnterHandler);
            ExecuteEvents.Execute(pressedObject, pointer, ExecuteEvents.pointerDownHandler);
            ExecuteEvents.Execute(pressedObject, pointer, ExecuteEvents.initializePotentialDrag);
        }

        private void UpdateDrag(Vector2 screen)
        {
            if (pointer == null || pressedObject == null) return;
            pointer.position = screen;
            ExecuteEvents.Execute(pressedObject, pointer, ExecuteEvents.dragHandler);
        }

        private void EndPinch()
        {
            if (pinching && pointer != null && pressedObject != null)
            {
                ExecuteEvents.Execute(pressedObject, pointer, ExecuteEvents.pointerUpHandler);
                ExecuteEvents.Execute(pressedObject, pointer, ExecuteEvents.pointerClickHandler);
                ExecuteEvents.Execute(pressedObject, pointer, ExecuteEvents.endDragHandler);
                ExecuteEvents.Execute(pressedObject, pointer, ExecuteEvents.pointerExitHandler);
            }
            pinching = false;
            pointer = null;
            pressedObject = null;
        }
    }
}
