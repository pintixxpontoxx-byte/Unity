using UnityEngine;

namespace HandOS
{
    public static class AndroidAppLauncher
    {
        // Example package ID: com.android.chrome
        public static bool Launch(string packageId)
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            if (string.IsNullOrWhiteSpace(packageId)) return false;
            try
            {
                using (var player = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
                using (var activity = player.GetStatic<AndroidJavaObject>("currentActivity"))
                using (var pm = activity.Call<AndroidJavaObject>("getPackageManager"))
                using (var intent = pm.Call<AndroidJavaObject>("getLaunchIntentForPackage", packageId))
                {
                    if (intent == null) return false;
                    activity.Call("startActivity", intent);
                    return true;
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError("HandOS: " + e.Message);
                return false;
            }
#else
            Debug.Log("Launch de apps funciona somente no Android.");
            return false;
#endif
        }
    }
}
