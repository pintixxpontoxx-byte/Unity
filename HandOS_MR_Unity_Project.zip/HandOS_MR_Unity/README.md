# HandOS MR — base Unity para Android

Este é um projeto-base Unity para continuar o app de realidade mista com câmera traseira e controle por gestos.

## O que já está incluído
- Estrutura de projeto Unity.
- Cursor de mão para interface UI.
- Gesto de pinça com início/fim e eventos de clique/arraste.
- Classe de entrada para receber pontos de mão.
- Tentativa de abrir aplicativos Android pelo ID do pacote.
- Configuração inicial de AR Foundation / ARCore.

## O que ainda precisa ser integrado
O rastreador real não vem embutido neste ZIP. É necessário importar uma implementação MediaPipe Hand Landmarker compatível com Unity e ligar sua saída ao `HandFrameReceiver.Publish()`. Sem isso, o cursor não recebe posições reais da mão. A cena também precisa ser configurada no Unity Editor para o dispositivo e a versão dos pacotes escolhidos.

## Abrir
1. Extraia o ZIP.
2. Abra Unity Hub > Add > Add project from disk e selecione esta pasta.
3. Use Unity 6 (6000.0.x) e instale Android Build Support, Android SDK & NDK Tools e OpenJDK.
4. Abra `Assets/Scenes/HandOS.unity`.
5. Configure a cena conforme `Assets/HandOS/SETUP_PT.md`.
6. Em File > Build Profiles, escolha Android e compile.

## Gerar APK
A compilação local exige Unity instalado. O workflow GitHub incluído também exige configurar `UNITY_LICENSE`, `UNITY_EMAIL` e `UNITY_PASSWORD` nos Secrets do repositório.

**Este ZIP é o código-fonte inicial, não um APK pronto.** O hand tracking real depende do adaptador MediaPipe e de teste no aparelho.
